<?php include "db1.php";
    
    ?>
    
<?php

if(isset($_POST['show']))
{
    global $connection;
    $id=$_POST['show'];
    $q="select * from incidents where adhaarNo='$id'";
    $r=mysqli_query($connection,$q);
    if(!$r) echo "err";
    while($row=mysqli_fetch_assoc($r))
    {
        echo $row['adhaarNo'];echo "<br>";
        
        echo $row['Type'];echo "<br>";
        echo $row['Victim'];echo "<br>";
        echo $row['mobileno'];echo "<br>";
        echo $row['email'];echo "<br>";
        echo $row['gender'];echo "<br>";
        
    }
    
}
?>